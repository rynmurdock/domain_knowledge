import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np

# plt.style.use('seaborn-colorblind')
plt.style.use('seaborn-deep')

markers = ['o', 'v', 'h', 'd', 'X', '8', 'P']
markers = [''] * len(markers)

# 512 data standard deviations are based on an unchanging validation set
# - dont' use them
# 32,32 data standard deviations have both the validation and training shuffled


plt.rcParams.update({'font.size': 16})


data = os.listdir('figures/data')

nets = [[512, 512], [32, 32]]
nets = [[32, 32]]


elem_props = ['onehot',
              'random_200',
              'magpie',
              'atom2vec',
              'mat2vec',
              'jarvis',
              'oliynyk']

pretty_descs = {'onehot': 'onehot',
                'random_200': 'random',
                'magpie': 'Magpie',
                'atom2vec': 'Atom2Vec',
                'mat2vec': 'mat2vec',
                'jarvis': 'Jarvis',
                'oliynyk': 'Oliynyk'}

material_props = ['ael_shear_modulus_vrh', 'energy_atom',
                  'agl_log10_thermal_expansion_300K',
                  'agl_thermal_conductivity_300K',
                  'Egap',
                  'ael_debye_temperature',
                  'ael_bulk_modulus_vrh']

to_symbols = {'energy_atom': '$\\Delta H$',
              'ael_shear_modulus_vrh': '$G$',
              'ael_bulk_modulus_vrh': '$B$',
              'ael_debye_temperature': '$\\theta$',
              'Egap': '$E_g$',
              'agl_thermal_conductivity_300K': '$\\kappa$',
              'agl_log10_thermal_expansion_300K': '$\\alpha$'}


def learning_cur(std=False, elem_props=elem_props):
    for sub, material_prop in enumerate(material_props):
        r2 = [0, 9, 12]
        style = r2
        plt.figure(figsize=(6, 6))
        for mr, elem_prop in enumerate(elem_props):
            location = 'figures/data/' + elem_prop+' -- ' + \
                material_prop+' -- ' + str(units)[1:-1] + '.csv'
            df = pd.read_csv(location)
            x = df.iloc[:, style[0]]
            y = df.iloc[:, style[1]]

            if std:
                y_std = df.iloc[:, style[2]]
                y_std_minus = y - 1.96*(y_std/np.sqrt(5))
                y_std_plus = y + 1.96*(y_std/np.sqrt(5))
                plt.fill_between(x, y_std_minus, y_std_plus, alpha=0.5)

            if elem_prop == 'onehot':
                plt.plot(x, y, '-', linewidth=12, color='silver',
                 label=pretty_descs[elem_prop], alpha=0.8, markersize=5)

            else:
                plt.plot(x, y, markers[mr] + '--', linewidth=3,
                         label=pretty_descs[elem_prop], alpha=1, markersize=5)
                if mr == 4:
                    plt.plot(x, y, markers[mr] + '--', linewidth=3,
                             label=None, alpha=1, markersize=5, color='gold')
            plt.xlabel('Number of Training Datapoints')
            plt.ylabel(f'r$^2$ ({to_symbols[material_prop]})')
            plt.yticks(np.arange(0, 1.1, 0.1))
            plt.ylim(0, 1)
            plt.tick_params(right=True, top=True, direction='in', length=7)
        plt.legend()
        if std:
            plt.savefig('figures/learning_curves/' + material_prop +
                        '_' + str(units)[1:-1] + '_1std_curve.png',
                        dpi=300, transparent=True)
        else:
            plt.savefig('figures/learning_curves/' + material_prop +
                        '_' + str(units)[1:-1] + '_learning_curve_r2.png',
                        dpi=300, transparent=True)


def to_p(x):
    return to_symbols[x]


def just_one():
    one_desc = 'jarvis'
    mse = [0, 8, 11]
    style = mse
    plt.figure(figsize=(6, 6))
    for mr, material_prop in enumerate(material_props):
        location = 'figures/data/' + one_desc + ' -- ' + material_prop + \
            ' -- '+str(units)[1:-1] + '.csv'
        df = pd.read_csv(location)
        x = df.iloc[:, style[0]]
        y = df.iloc[:, style[1]]

        plt.tick_params(right=True, top=True, direction='in', length=7)
        # plt.yticks(np.arange(0, 1.1, 0.1))
        plt.plot(np.log(x), np.log(np.sqrt(y)), markers[mr] + '--',
                 linewidth=2, markersize=10,
                 label=to_symbols[material_prop], alpha=1)
        plt.xlabel('Number of Training Datapoints')
        plt.ylabel('RMSE')
        # plt.ylim(0, 1)
    plt.legend(loc='upper right')
    plt.savefig('figures/learning_curves/just_' + one_desc +
                str(units)[1:-1] + '_learning_curve_rmse.png',
                dpi=300, transparent=True)


def curve_rates():
    mse = [0, 8, 11]
    style = mse
    plt.figure(figsize=(6, 6))
    for mr, elem_prop in enumerate(elem_props):
        line = []
        lb = []
        for material_prop in material_props:
            location = 'figures/data/' + elem_prop + ' -- ' +\
                material_prop + ' -- ' + str(units)[1:-1] + '.csv'
            df = pd.read_csv(location)
            x = np.log(df.iloc[:, style[0]].values)
            y = np.log(np.sqrt(df.iloc[:, style[1]].values))
            line.append((y[0]-y[-1])/x[-1])
            lb.append(to_symbols[material_prop])

        plt.tick_params(right=True, top=True, direction='in', length=7)
        plt.plot(lb, line, markers[mr] + '--', linewidth=2,
                 markersize=10, label=pretty_descs[elem_prop])
        # plt.xlabel('Material Property')
    plt.ylabel('RMSE Rate of Decline')
    plt.legend(loc='upper left')
    plt.savefig('figures/learning_curves/' + str(units)[1:-1] +
                '_rates_rmse.png',
                dpi=300, transparent=True)


def multi_figure(mat_props, std=False):
    fig = plt.figure(figsize=(6, 6))
    for sub, material_prop in enumerate(mat_props):
        r2 = [0, 9, 12]
        style = r2

        fig.text(0.5, 0.04, 'Number of Training Datapoints',
                 ha='center', va='center')
        fig.text(0.06, 0.5, 'r$^2$', ha='center',
                 va='center', rotation='vertical')

        for mr, elem_prop in enumerate(elem_props):
            location = 'figures/data/' + elem_prop + ' -- ' + \
                material_prop + ' -- ' + str(units)[1:-1] + '.csv'
            df = pd.read_csv(location)
            x = df.iloc[:, style[0]]
            y = df.iloc[:, style[1]]

            if std:
                y_std = df.iloc[:, style[2]]
                y_std_minus = y - 1.96*(y_std/np.sqrt(5))
                y_std_plus = y + 1.96*(y_std/np.sqrt(5))
                plt.fill_between(x, y_std_minus, y_std_plus, alpha=0.5)

            plt.tick_params(right=True, top=True, direction='in', length=7)
            plt.yticks(np.arange(0, 1.1, 0.1))
            plt.plot(x, y, markers[mr] + '--', linewidth=2,
                     markersize=10, label=pretty_descs[elem_prop], alpha=1)
            plt.ylim(0, 1)
            plt.title(to_symbols[material_prop])
    plt.legend()
    if std:
        plt.savefig('figures/learning_curves/' + '_' +
                    str(units)[1:-1] + '_1std_many_curve.png',
                    dpi=300, transparent=True)
    else:
        plt.savefig('figures/learning_curves/' + '_' + str(units)[1:-1] +
                    '_many_curves.png',
                    dpi=300, transparent=True)


for units in nets:
    learning_cur()
    plt.show()
    
    # just_one()
    # plt.show()
    
    # curve_rates()
    # plt.show()
    
    # # if units == [32, 32]:
    # learning_cur(elem_props=['oliynyk',
    #                          'jarvis',
    #                          'onehot'], std=True)
    # plt.show()
    
    # multi_figure([['ael_shear_modulus_vrh',
    #               'ael_debye_temperature',
    #               'Egap',
    #               'energy_atom']])
    # plt.show()
